const button = document.getElementById('button');
const username = document.getElementById('username');
const password = document.getElementById('password');
const user = document.getElementById('user')
const pass = document.getElementById('pass')

function showName(inputName) {
    user.innerText = inputName;
}

function showPass(inputPass) {
    pass.innerText = inputPass;
}
button.addEventListener('click', () => {
    showName(username.value)
})

button.addEventListener('click', () => {
    showPass(password.value)
})


